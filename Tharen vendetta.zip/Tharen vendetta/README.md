# pixel-fighter
 A pixel art fighting game made using HTML Canvas. (Made by watching a youtube tutorial.)
